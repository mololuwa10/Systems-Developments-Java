package SMMCompetitor;
import GUI.FileChooser;

import java.io.FileWriter;
import java.util.*;
import java.sql.SQLOutput;

public class Manager {
    public static void main(String[] args) {
//        CompetitorList football = new CompetitorList();
        FileChooser fileChooser = new FileChooser();
        fileChooser.createGUI();
    }
}
